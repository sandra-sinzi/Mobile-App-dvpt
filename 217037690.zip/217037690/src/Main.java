import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        Scanner inputText = new Scanner(System.in);

        double grossSalary = 500000, hour_rate = 2500, netSalary, hrsNo, reduction;

        String name;
        String empType;

        System.out.println ("Enter employee's name");

        name = inputText.nextLine();

        System.out.println ("Enter Employee type M (Monthly), W (Weekly), H (Hourly)");

        empType = inputText.nextLine();

        if (empType.equals("M") || empType.equals("m")){

            reduction = (grossSalary * 0.3) + (grossSalary * 0.03);

            netSalary = grossSalary - reduction;

            System.out.println("Names : " + name);
            System.out.println("Employee type : Monthly");
            System.out.println("Net Salary : " + netSalary);


        }else if (empType.equals("W") || empType.equals("w")){

            reduction = (grossSalary * 0.03);

            netSalary = grossSalary - reduction;

            System.out.println("Names : " + name);
            System.out.println("Employee type : Weekly");
            System.out.println("Net Salary : " + netSalary);

        }else{

            System.out.println ("Number of hours");

            hrsNo = Double.parseDouble(inputText.nextLine());

            netSalary = hour_rate * hrsNo;

            System.out.println("Names : " + name);
            System.out.println("Employee type : Hourly" );
            System.out.println("Net Salary : " + netSalary);

        }
    }
}
